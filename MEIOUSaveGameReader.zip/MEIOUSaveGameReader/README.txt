Installation:

Extract this .rar file into your save game location (should be in \Documents\Paradox Interactive\Europa Universalis IV\save games), then run "launchMe.bat")

NOTE: THE SAVE FILE MUST BE UNCOMPRESSED.

CHANGELOG:
V 0.1: Set up basic systems, hack with XChart 
V 0.15: Added option to include subjects, heretics are now sorted under their own categories.
V 0.2: Official release! You can now compare your nation to the rest of the world. Added an option to see production and cities.
LICENSE: 

https://www.youtube.com/watch?v=2t4VphTeogo

Credit to XChart for letting me use their awesome system to generate charts